import React from 'react';

interface RetroScreenProps {
  children: React.ReactNode;
}

export function RetroScreen({ children }: RetroScreenProps) {
  return (
    <div className="retro-screen">
      <div className="retro-content p-8 text-center">
        {children}
      </div>
    </div>
  );
}