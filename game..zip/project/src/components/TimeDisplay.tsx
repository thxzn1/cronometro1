import React from 'react';
import { Clock } from 'lucide-react';
import { getBrasiliaTime, getBrasiliaDate } from '../utils/dateTime';

interface TimeDisplayProps {
  time: Date;
}

export function TimeDisplay({ time }: TimeDisplayProps) {
  return (
    <>
      <div className="mb-4 flex justify-center">
        <Clock className="text-green-500 w-12 h-12" />
      </div>
      <h1 className="text-xl mb-2 text-green-500 font-bold">HORÁRIO DE BRASÍLIA</h1>
      <div className="time-display text-6xl font-mono text-green-500 tracking-wider">
        {getBrasiliaTime(time)}
      </div>
      <div className="mt-4 text-green-500 text-sm">
        {getBrasiliaDate(time)}
      </div>
    </>
  );
}