import React from 'react';

interface PipeProps {
  height: number;
  position: number;
  isTop?: boolean;
}

export function Pipe({ height, position, isTop }: PipeProps) {
  return (
    <div
      className="absolute w-16 bg-green-500"
      style={{
        height: `${height}px`,
        left: `${position}px`,
        top: isTop ? 0 : 'auto',
        bottom: isTop ? 'auto' : 0,
        boxShadow: '0 0 10px rgba(0, 255, 0, 0.5)',
      }}
    >
      <div className={`absolute w-20 h-8 bg-green-600 left-1/2 transform -translate-x-1/2 ${isTop ? 'bottom-0' : 'top-0'}`} />
    </div>
  );
}