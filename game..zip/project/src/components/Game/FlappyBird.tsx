import React, { useState, useEffect, useCallback } from 'react';
import { Bird } from './Bird';
import { Pipe } from './Pipe';
import { GameOver } from './GameOver';
import { useGameLogic } from '../../hooks/useGameLogic';

export function FlappyBird() {
  const {
    birdPosition,
    birdRotation,
    pipes,
    score,
    highScore,
    gameOver,
    startGame,
    jump,
  } = useGameLogic();

  const handleKeyPress = useCallback((e: KeyboardEvent) => {
    if (e.code === 'Space') {
      e.preventDefault();
      jump();
    }
  }, [jump]);

  useEffect(() => {
    window.addEventListener('keydown', handleKeyPress);
    return () => window.removeEventListener('keydown', handleKeyPress);
  }, [handleKeyPress]);

  return (
    <div 
      className="relative w-full h-[600px] bg-gradient-to-b from-blue-400 to-blue-600 overflow-hidden cursor-pointer"
      onClick={jump}
    >
      <div className="absolute top-4 left-4 text-white text-2xl font-bold">
        Score: {score}
      </div>
      
      <Bird position={birdPosition} rotation={birdRotation} />
      
      {pipes.map((pipe, index) => (
        <React.Fragment key={pipe.id}>
          <Pipe height={pipe.topHeight} position={pipe.x} isTop />
          <Pipe height={pipe.bottomHeight} position={pipe.x} />
        </React.Fragment>
      ))}

      {gameOver && (
        <GameOver
          score={score}
          highScore={highScore}
          onRestart={startGame}
        />
      )}
    </div>
  );
}