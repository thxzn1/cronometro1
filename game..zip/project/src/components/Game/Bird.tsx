import React from 'react';

interface BirdProps {
  position: number;
  rotation: number;
}

export function Bird({ position, rotation }: BirdProps) {
  return (
    <div 
      className="absolute w-8 h-8 bg-yellow-400 rounded-full"
      style={{
        top: `${position}px`,
        left: '50px',
        transform: `rotate(${rotation}deg)`,
        transition: 'transform 0.1s',
        boxShadow: '0 0 10px rgba(0, 255, 0, 0.5)',
      }}
    >
      <div className="absolute w-3 h-3 bg-white rounded-full top-1 left-1" />
      <div className="absolute w-2 h-2 bg-black rounded-full top-2 left-2" />
      <div className="absolute w-4 h-2 bg-orange-600 -right-1 top-3 transform rotate-45" />
    </div>
  );
}