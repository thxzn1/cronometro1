import React from 'react';

interface GameOverProps {
  score: number;
  highScore: number;
  onRestart: () => void;
}

export function GameOver({ score, highScore, onRestart }: GameOverProps) {
  return (
    <div className="absolute inset-0 flex items-center justify-center bg-black bg-opacity-50">
      <div className="text-center">
        <h2 className="text-4xl font-bold text-green-500 mb-4">GAME OVER</h2>
        <p className="text-2xl text-green-400 mb-2">Score: {score}</p>
        <p className="text-xl text-green-400 mb-4">High Score: {highScore}</p>
        <button
          onClick={onRestart}
          className="px-6 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-opacity-50 transition-colors"
        >
          Play Again
        </button>
      </div>
    </div>
  );
}