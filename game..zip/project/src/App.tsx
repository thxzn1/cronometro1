import React from 'react';
import { RetroScreen } from './components/RetroScreen';
import { FlappyBird } from './components/Game/FlappyBird';

function App() {
  return (
    <div className="min-h-screen bg-black flex items-center justify-center p-4">
      <RetroScreen>
        <div className="w-[800px]">
          <FlappyBird />
        </div>
      </RetroScreen>
    </div>
  );
}

export default App;