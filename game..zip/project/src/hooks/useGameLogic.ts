import { useState, useEffect, useCallback } from 'react';

interface Pipe {
  id: number;
  x: number;
  topHeight: number;
  bottomHeight: number;
}

const GRAVITY = 0.6;
const JUMP_FORCE = -10;
const PIPE_SPEED = 3;
const PIPE_SPAWN_RATE = 1500;
const GAP_SIZE = 150;

export function useGameLogic() {
  const [birdPosition, setBirdPosition] = useState(300);
  const [birdVelocity, setBirdVelocity] = useState(0);
  const [birdRotation, setBirdRotation] = useState(0);
  const [pipes, setPipes] = useState<Pipe[]>([]);
  const [gameStarted, setGameStarted] = useState(false);
  const [gameOver, setGameOver] = useState(false);
  const [score, setScore] = useState(0);
  const [highScore, setHighScore] = useState(0);

  const createPipe = useCallback(() => {
    const minHeight = 50;
    const maxHeight = 400;
    const topHeight = Math.random() * (maxHeight - minHeight) + minHeight;
    const bottomHeight = 600 - topHeight - GAP_SIZE;
    
    return {
      id: Date.now(),
      x: 800,
      topHeight,
      bottomHeight,
    };
  }, []);

  const startGame = useCallback(() => {
    setBirdPosition(300);
    setBirdVelocity(0);
    setBirdRotation(0);
    setPipes([]);
    setGameStarted(true);
    setGameOver(false);
    setScore(0);
  }, []);

  const jump = useCallback(() => {
    if (!gameStarted) {
      startGame();
    }
    if (!gameOver) {
      setBirdVelocity(JUMP_FORCE);
    }
  }, [gameStarted, gameOver, startGame]);

  const checkCollision = useCallback((birdPos: number, pipes: Pipe[]) => {
    const birdRect = {
      top: birdPos,
      bottom: birdPos + 32,
      left: 50,
      right: 82,
    };

    return pipes.some(pipe => {
      const hitTopPipe = 
        birdRect.right > pipe.x &&
        birdRect.left < pipe.x + 64 &&
        birdRect.top < pipe.topHeight;

      const hitBottomPipe =
        birdRect.right > pipe.x &&
        birdRect.left < pipe.x + 64 &&
        birdRect.bottom > 600 - pipe.bottomHeight;

      return hitTopPipe || hitBottomPipe;
    });
  }, []);

  useEffect(() => {
    if (!gameStarted || gameOver) return;

    const gameLoop = setInterval(() => {
      setBirdPosition(pos => {
        const newPos = pos + birdVelocity;
        if (newPos < 0 || newPos > 568) {
          setGameOver(true);
          if (score > highScore) setHighScore(score);
          return pos;
        }
        return newPos;
      });

      setBirdVelocity(vel => vel + GRAVITY);
      setBirdRotation(birdVelocity * 2);

      setPipes(pipes => {
        const newPipes = pipes
          .map(pipe => ({ ...pipe, x: pipe.x - PIPE_SPEED }))
          .filter(pipe => pipe.x > -64);

        if (checkCollision(birdPosition, newPipes)) {
          setGameOver(true);
          if (score > highScore) setHighScore(score);
        }

        return newPipes;
      });
    }, 1000 / 60);

    return () => clearInterval(gameLoop);
  }, [gameStarted, gameOver, birdPosition, birdVelocity, score, highScore, checkCollision]);

  useEffect(() => {
    if (!gameStarted || gameOver) return;

    const spawnPipe = setInterval(() => {
      setPipes(pipes => [...pipes, createPipe()]);
      setScore(score => score + 1);
    }, PIPE_SPAWN_RATE);

    return () => clearInterval(spawnPipe);
  }, [gameStarted, gameOver, createPipe]);

  return {
    birdPosition,
    birdRotation,
    pipes,
    score,
    highScore,
    gameOver,
    gameStarted,
    startGame,
    jump,
  };
}